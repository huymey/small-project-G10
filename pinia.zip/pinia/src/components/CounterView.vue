<template>
    <div class="count">
        {{storeCounter.count}}
    </div>
</template>
<script setup>
import { useCounterStore } from "@/store/index";

const storeCounter = useCounterStore();

</script>