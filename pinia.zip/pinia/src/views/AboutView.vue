<template>
  <div class="about">
    <h1>This is an about page</h1>
    <button 
    @click="storeCounter.increaseCount"
    class="counter-button">
{{storeCounter.count}}
    </button>
  </div>
</template>
<script setup>
import { useCounterStore } from '@/store/index';

const storeCounter = useCounterStore()
</script>
<style >
.counter-button{
  font-size: 50px;
  border:none;
  border-radius: 10px;
  background: rgb(29, 249, 227);
}
</style>
