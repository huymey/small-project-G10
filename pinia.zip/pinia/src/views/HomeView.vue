<template>
  <div class="home">
    <counter-view />
    <div class="buttons">
      <button @click="storeCounter.decreaseCount">-</button>
      <button @click="storeCounter.increaseCount">+</button>
    </div>
    <div class="odd-even">This counter is : <span>{{ storeCounter.oddOrEven }}</span> </div>
    <div>
      <h3>Edit counter:</h3>
      <input v-model="storeCounter.count" type="number" />
    </div>
  </div>
</template>
<script setup>

import { useCounterStore } from "@/store/index";

const storeCounter = useCounterStore();

</script>
<style>
.home {
  width: 50%;
  margin: auto;
}

.count {
  font-size: 60px;
  margin: 20px;
}

.buttons button {
  font-size: 40px;
  margin: 10px;
  border: none;
  border-radius: 10px;
  background: rgb(29, 249, 227);
}

.odd-even {
  padding: 10px;
  border-bottom: 2px solid rgb(29, 249, 227);
  border-top: 2px solid rgb(29, 249, 227)
}

span {
  color: red
}

input {
  width: 50%;
  padding: 10px;
  color: red;
  font-size: 20px;
}
</style>
